
import Foundation
import SwiftUI
import PlaygroundSupport

PlaygroundPage.current.setLiveView(View9())

struct View9: View {
    
    @State var scaledUp = true
    
    var body: some View {
                VStack {
                    Image(uiImage: UIImage(named: "grafica9.jpg")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 400, height: 300)
                        .border(Color.black, width: 10)
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                        .rotationEffect(.degrees(180))
                    
                    Text("Ethan and Liam get inside the vault and finally open the security box.\nNo money, no gold, no diamonds but just another piece of paper on which there is \na strange map and another message:")
                        .frame(width: 400, height: 150)
                        .font(Font.custom("American Typewriter", size: 20.0))
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                        .scaleEffect(scaledUp ? 0 : 1)
                        .animation(.linear(duration: 0.9), value: scaledUp)
                        .onTapGesture {scaledUp.toggle()}
                            
                    Button(action:{PlaygroundPage.current.setLiveView(View101())},
                           label: {
                        Text("Continue")
                            .bold()
                            .font(Font.custom("American Typewriter", size: 20.0))
                            .foregroundColor(.brown)
                            .frame(width: 400, height: 100)
                            .position(x: 200, y: 10)
                            .shadow(radius: 10)
                            })
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                    }
                .frame(width: 400, height: 600)
            }
}

struct View101: View {
    
    @State var scaledUp = true
    
    var body: some View {
                VStack {
                    Image(uiImage: UIImage(named: "grafica10.jpg")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 400, height: 300)
                        .border(Color.black, width: 10)
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                        .rotationEffect(.degrees(180))
                    
                    Text("'This box doesn’t contain what you could be thinking I’ve promised, but trust me, there’s a lot more than this...'")
                        .frame(width: 400, height: 150)
                        .font(Font.custom("American Typewriter", size: 20.0))
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                        .scaleEffect(scaledUp ? 0 : 1)
                        .animation(.linear(duration: 0.9), value: scaledUp)
                        .onTapGesture {scaledUp.toggle()}
                            
                    Button(action:{PlaygroundPage.current.setLiveView(View102())},
                           label: {
                        Text("Continue")
                            .bold()
                            .font(Font.custom("American Typewriter", size: 20.0))
                            .foregroundColor(.brown)
                            .frame(width: 400, height: 100)
                            .position(x: 200, y: 10)
                            .shadow(radius: 10)
                            })
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                    }
                .frame(width: 400, height: 600)
            }
}

struct View102: View {
    
    @State var scaledUp = true
    
    var body: some View {
                VStack {
                    Image(uiImage: UIImage(named: "grafica10.jpg")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 400, height: 300)
                        .border(Color.black, width: 10)
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                        .rotationEffect(.degrees(180))
                    
                    Text("...more than all the gold you can imagine, just follow this map and get where I want you to go. The truth is close but you will have to find it together.'")
                        .frame(width: 400, height: 150)
                        .font(Font.custom("American Typewriter", size: 20.0))
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                        .scaleEffect(scaledUp ? 0 : 1)
                        .animation(.linear(duration: 0.9), value: scaledUp)
                        .onTapGesture {scaledUp.toggle()}
                            
                    Button(action:{PlaygroundPage.current.setLiveView(View103())},
                           label: {
                        Text("Continue")
                            .bold()
                            .font(Font.custom("American Typewriter", size: 20.0))
                            .foregroundColor(.brown)
                            .frame(width: 400, height: 100)
                            .position(x: 200, y: 10)
                            .shadow(radius: 10)
                            })
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                    }
                .frame(width: 400, height: 600)
            }
}

struct View103: View {
    
    @State var scaledUp = true
    
    var body: some View {
                VStack {
                    Image(uiImage: UIImage(named: "grafica10.jpg")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 400, height: 300)
                        .border(Color.black, width: 10)
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                        .rotationEffect(.degrees(180))
                    
                    Text("The two guys are terrified and astonished at the same time, they wonder what they will find. At this point they can’t stand back and decide to reach the mysterious place.")
                        .frame(width: 400, height: 150)
                        .font(Font.custom("American Typewriter", size: 20.0))
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                        .scaleEffect(scaledUp ? 0 : 1)
                        .animation(.linear(duration: 0.9), value: scaledUp)
                        .onTapGesture {scaledUp.toggle()}
                            
                    Button(action:{PlaygroundPage.current.setLiveView(View103())},
                           label: {
                        Text("Next page for Riddle 2")
                            .bold()
                            .font(Font.custom("American Typewriter", size: 20.0))
                            .foregroundColor(.brown)
                            .frame(width: 400, height: 100)
                            .position(x: 200, y: 10)
                            .shadow(radius: 10)
                            })
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                    }
                .frame(width: 400, height: 600)
            }
}

//:[Next page for Riddle 2](Riddle2)







//public struct View9: View {
//    @State private var scaledUp = true
//
//    public var body: some View {
//        ZStack {
//            Image(uiImage: UIImage(named: "sfondoimm.jpeg")!)
//                .resizable()
//                .scaledToFit()
//            VStack {
//                    Image(uiImage: UIImage(named: "grafica9.png")!)
//                    .resizable()
//                    .scaledToFit()
//                    .padding(2)
//                    .cornerRadius(5)
//                    .padding(5)
//                    .background(Color.black)
//                    .cornerRadius(5)
//                    .frame(width: 400, height: 300)
//                    Text("Ethan and Liam get inside the vault and, once the banker leaves them alone, they can finally open the security box. No money, no gold, no diamonds but just another piece of paper on which there is a strange map and another message:")
//                        .font(.system(size: 16, weight: .light, design: .serif))
//                        .padding(20)
//                        .multilineTextAlignment(.center)
//                        .scaleEffect(scaledUp ? 0 : 1)
//                        .animation(.linear(duration: 0.9), value: scaledUp)
//                        .onTapGesture { scaledUp.toggle() }
//                        .frame(width: 400, height: 300)
//                    Button(action: {
//                                    PlaygroundPage.current.setLiveView(View10())
//                                }) {
//                                    HStack(spacing: 10) {
//                                        Text("Continue")
//                                        Image(systemName: "arrowtriangle.down")
//                                            .resizable()
//                                                .frame(width: 10, height: 10)
//                                    }
//                                }.offset(x: 120, y: -60)
//                        .foregroundColor(.black)
//                }
//        }
//        .frame(width: 400, height:600)
//
//    }
//
//}
//
//public struct View10: View {
//    @State private var scaledUp = true
//
//    public var body: some View {
//        ZStack {
//            Image(uiImage: UIImage(named: "sfondoimm.jpeg")!)
//                .resizable()
//                .scaledToFit()
//            VStack {
//                    Image(uiImage: UIImage(named: "grafica10.png")!)
//                    .resizable()
//                    .scaledToFit()
//                    .padding(2)
//                    .cornerRadius(5)
//                    .padding(5)
//                    .background(Color.black)
//                    .cornerRadius(5)
//                    .frame(width: 400, height: 300)
//                    Text("'Dear guys, this box doesn’t contain what you could be thinking I’ve promised, but trust me, there’s a lot more than this, more than all the gold you can imagine, just follow this map and get where I want you to go. The truth is close but you will have to find it together.'")
//                        .font(.system(size: 16, weight: .light, design: .serif))
//                        .padding(20)
//                        .multilineTextAlignment(.center)
//                        .scaleEffect(scaledUp ? 0 : 1)
//                        .animation(.linear(duration: 0.9), value: scaledUp)
//                        .onTapGesture { scaledUp.toggle() }
//                        .frame(width: 400, height: 300)
//                    Button(action: {
//                                    PlaygroundPage.current.setLiveView(View11())
//                                }) {
//                                    HStack(spacing: 10) {
//                                        Text("Continue")
//                                        Image(systemName: "arrowtriangle.down")
//                                            .resizable()
//                                                .frame(width: 10, height: 10)
//                                    }
//                                }.offset(x: 120, y: -60)
//                        .foregroundColor(.black)
//                }
//        }
//        .frame(width: 400, height:600)
//
//    }
//
//}
//
//public struct View11: View {
//    @State private var scaledUp = true
//
//    public var body: some View {
//        ZStack {
//            Image(uiImage: UIImage(named: "sfondoimm.jpeg")!)
//                .resizable()
//                .scaledToFit()
//            VStack {
//                    Image(uiImage: UIImage(named: "grafica10.png")!)
//                    .resizable()
//                    .scaledToFit()
//                    .padding(2)
//                    .cornerRadius(5)
//                    .padding(5)
//                    .background(Color.black)
//                    .cornerRadius(5)
//                    .frame(width: 400, height: 300)
//                    Text("The two guys are terrified and astonished at the same time, they wonder what they will find, what kind of wealths and why all this was happening to them. At this point they can’t stand back and decide to collaborate to find the mysterious place of the message.")
//                        .font(.system(size: 16, weight: .light, design: .serif))
//                        .padding(20)
//                        .multilineTextAlignment(.center)
//                        .scaleEffect(scaledUp ? 0 : 1)
//                        .animation(.linear(duration: 0.9), value: scaledUp)
//                        .onTapGesture { scaledUp.toggle() }
//                        .frame(width: 400, height: 300)
//                    Button(action: {
//                                    PlaygroundPage.current.setLiveView(View10())
//                                }) {
//                                    HStack(spacing: 10) {
//                                        Text("Continue")
//                                        Image(systemName: "arrowtriangle.down")
//                                            .resizable()
//                                                .frame(width: 10, height: 10)
//                                    }
//                                }.offset(x: 120, y: -60)
//                        .foregroundColor(.black)
//                }
//        }
//        .frame(width: 400, height:600)
//
//    }
//
//}






