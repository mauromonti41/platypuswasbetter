import Foundation
import SwiftUI
import PlaygroundSupport

PlaygroundPage.current.setLiveView(View11())

struct View11: View {
    
    @State var scaledUp = true
    
    var body: some View {
                VStack {
                    Image(uiImage: UIImage(named: "grafica11.jpg")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 400, height: 300)
                        .border(Color.black, width: 10)
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                        .rotationEffect(.degrees(180))
                    
                    Text("Ethan and Liam arrive at a huge opened gate with a plate that says: “Byrne Orphanage”. They walk inside the awful property and finally get to what seems the final point of their journey.")
                        .frame(width: 400, height: 150)
                        .font(Font.custom("American Typewriter", size: 20.0))
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                        .scaleEffect(scaledUp ? 0 : 1)
                        .animation(.linear(duration: 0.9), value: scaledUp)
                        .onTapGesture {scaledUp.toggle()}
                            
                    Button(action:{PlaygroundPage.current.setLiveView(View12())},
                           label: {
                        Text("Continue")
                            .bold()
                            .font(Font.custom("American Typewriter", size: 20.0))
                            .foregroundColor(.brown)
                            .frame(width: 400, height: 100)
                            .position(x: 200, y: 10)
                            .shadow(radius: 10)
                            })
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                    }
                .frame(width: 400, height: 600)
            }
}

struct View12: View {
    
    @State var scaledUp = true
    
    var body: some View {
                VStack {
                    Image(uiImage: UIImage(named: "grafica12.jpg")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 400, height: 300)
                        .border(Color.black, width: 10)
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                        .rotationEffect(.degrees(180))
                    
                    Text("They enter in the abandoned structure,\nit seems all abandoned. Ethan notices the entrance of a ceiling. Since it is the last place to check, they get inside and find a little box closed by means of an \nelectronic padlock.")
                        .frame(width: 400, height: 150)
                        .font(Font.custom("American Typewriter", size: 20.0))
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                        .scaleEffect(scaledUp ? 0 : 1)
                        .animation(.linear(duration: 0.9), value: scaledUp)
                        .onTapGesture {scaledUp.toggle()}
                            
                    Button(action:{PlaygroundPage.current.setLiveView(View12())},
                           label: {
                        Text("Next page for Riddle 3")
                            .bold()
                            .font(Font.custom("American Typewriter", size: 20.0))
                            .foregroundColor(.brown)
                            .frame(width: 400, height: 100)
                            .position(x: 200, y: 10)
                            .shadow(radius: 10)
                            })
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                    }
                .frame(width: 400, height: 600)
            }
}

//:[Next page for Riddle 3](Riddle3)

//public struct View12: View {
//    @State private var scaledUp = true
//
//    public var body: some View {
//        ZStack {
//            Image(uiImage: UIImage(named: "sfondoimm.jpeg")!)
//                .resizable()
//                .scaledToFit()
//            VStack {
//                    Image(uiImage: UIImage(named: "grafica11.png")!)
//                    .resizable()
//                    .scaledToFit()
//                    .padding(2)
//                    .cornerRadius(5)
//                    .padding(5)
//                    .background(Color.black)
//                    .cornerRadius(5)
//                    .frame(width: 400, height: 300)
//                    Text("Ethan and Liam arrive at a huge opened gate with a plate that says: “Byrne Orphanage”. It seems so strange to the guys that it is exactly an orphanage, full of children as they were used to be. They get inside the awful property and notice that no one is there apart from them. They walk inside and finally get to what seems the final point of their journey.")
//                        .font(.system(size: 16, weight: .light, design: .serif))
//                        .padding(20)
//                        .multilineTextAlignment(.center)
//                        .scaleEffect(scaledUp ? 0 : 1)
//                        .animation(.linear(duration: 0.9), value: scaledUp)
//                        .onTapGesture { scaledUp.toggle() }
//                        .frame(width: 400, height: 300)
//                    Button(action: {
//                                    PlaygroundPage.current.setLiveView(View13())
//                                }) {
//                                    HStack(spacing: 10) {
//                                        Text("Continue")
//                                        Image(systemName: "arrowtriangle.down")
//                                            .resizable()
//                                                .frame(width: 10, height: 10)
//                                    }
//                                }.offset(x: 120, y: -60)
//                        .foregroundColor(.black)
//                }
//        }
//        .frame(width: 400, height:600)
//
//    }
//
//}
//
//public struct View13: View {
//    @State private var scaledUp = true
//
//    public var body: some View {
//        ZStack {
//            Image(uiImage: UIImage(named: "sfondoimm.jpeg")!)
//                .resizable()
//                .scaledToFit()
//            VStack {
//                    Image(uiImage: UIImage(named: "grafica12.png")!)
//                    .resizable()
//                    .scaledToFit()
//                    .padding(2)
//                    .cornerRadius(5)
//                    .padding(5)
//                    .background(Color.black)
//                    .cornerRadius(5)
//                    .frame(width: 400, height: 300)
//                    Text("They enter in the abandoned structure and try to look for something that could explain the reason of the testament and the other messages. It seems all abandoned and useless for what they are looking for. Ethan notices the entrance of a ceiling. Since it is the last place to check, they get inside and notice a little box closed by means of an electronic padlock that requires a password.")
//                        .font(.system(size: 16, weight: .light, design: .serif))
//                        .padding(20)
//                        .multilineTextAlignment(.center)
//                        .scaleEffect(scaledUp ? 0 : 1)
//                        .animation(.linear(duration: 0.9), value: scaledUp)
//                        .onTapGesture { scaledUp.toggle() }
//                        .frame(width: 400, height: 300)
//                    Button(action: {
//                                    PlaygroundPage.current.setLiveView(View13())
//                                }) {
//                                    HStack(spacing: 10) {
//                                        Text("Continue")
//                                        Image(systemName: "arrowtriangle.down")
//                                            .resizable()
//                                                .frame(width: 10, height: 10)
//                                    }
//                                }.offset(x: 120, y: -60)
//                        .foregroundColor(.black)
//                }
//        }
//        .frame(width: 400, height:600)
//
//    }
//
//}
