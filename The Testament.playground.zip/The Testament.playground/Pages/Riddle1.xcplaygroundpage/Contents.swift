import SwiftUI
import PlaygroundSupport
import Foundation
import AVFoundation
import CoreMedia
import UIKit

PlaygroundPage.current.setLiveView(Riddle1())

struct RightChoice: View {
    var body: some View {
        ZStack {
        VStack {
            Image(uiImage: UIImage(named: "barra.png")!)
                .resizable()
                .scaledToFit()
                .rotationEffect(.degrees(180))
            Text("That's right! Let's move on!")
                .font(Font.custom("American Typewriter", size: 16.0))
            Button("Click on 'Go to that Place'") {
                
            }
            .font(Font.custom("American Typewriter", size: 20.0))
            .background(Color.blue.opacity(0.4))
            .foregroundColor(.black)
            .cornerRadius(10)
            .buttonStyle(.bordered)
            Image(uiImage: UIImage(named: "barra.png")!)
                                    .resizable()
                                    .scaledToFit()
        }
        .frame(width: 400, height: 600)
            
        }
    }
}

struct Riddle1: View {
    
    var body: some View {
        ZStack {
        VStack {
            VStack{
                Spacer()
            Image(uiImage: UIImage(named: "riddle1.jpeg")!)
                    .resizable()
                                        .scaledToFit()
                                        .padding(2)
                                        .cornerRadius(5)
                                        .padding(5)
                                        .background(Color.black)
                                        .cornerRadius(5)
                                        .frame(width: 400, height: 280)
            }
            VStack {
                                    Image(uiImage: UIImage(named: "barra.png")!)
                                        .resizable()
                                        .rotationEffect(.degrees(180))
                Button("Hint") {
                    PlaygroundPage.current.setLiveView(Hint())
                }
                .font(Font.custom("American Typewriter", size: 20.0))
            Text("What does it mean?")
                    .font(Font.custom("American Typewriter", size: 20.0))
            Button("Central Park, Blue Postal Box, Behind Bushes") {
                PlaygroundPage.current.setLiveView(WrongChoice())
            }
            .font(Font.custom("American Typewriter", size: 16.0))
            .border(Color.black, width: 2)
            .background(Color.blue.opacity(0.1))
            .foregroundColor(.black)
            .cornerRadius(10)
            .buttonStyle(.bordered)
            Button("Central Bank, Safe Deposit Box, Number Twelve") {
                PlaygroundPage.current.setLiveView(RightChoice())
            }
            .font(Font.custom("American Typewriter", size: 16.0))
            .border(Color.black, width: 2)
            .background(Color.blue.opacity(0.1))
            .foregroundColor(.black)
            .cornerRadius(10)
            .buttonStyle(.bordered)
            Button("Central Post, Safe Deposit Box, Number Eleven") {
                PlaygroundPage.current.setLiveView(WrongChoice())
            }
            .font(Font.custom("American Typewriter", size: 16.0))
            .border(Color.black, width: 2)
            .background(Color.blue.opacity(0.1))
            .foregroundColor(.black)
            .cornerRadius(10)
            .buttonStyle(.bordered)
                Image(uiImage: UIImage(named: "barra.png")!)
                                        .resizable()
        }
            .frame(width: 400, height: 300)
        }
        .frame(width: 400, height: 600)
    }
    }
}

struct WrongChoice: View {
    var body: some View {
        ZStack {
        VStack {
            VStack{
                VStack {
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                        .scaledToFit()
                        .rotationEffect(.degrees(180))
                    Text("That's not right...")
                        .font(Font.custom("American Typewriter", size: 16.0))
                    Button("Retry") {
                        PlaygroundPage.current.setLiveView(Riddle1())
                    }
                    .font(Font.custom("American Typewriter", size: 20.0))
                    .background(Color.blue.opacity(0.4))
                    .foregroundColor(.black)
                    .cornerRadius(10)
                    .buttonStyle(.bordered)
                    Image(uiImage: UIImage(named: "barra.png")!)
                                            .resizable()
                                            .scaledToFit()
                }
        }
        }
        .frame(width: 400, height: 600)
    }
        
    }
}

struct Hint: View {
    var body: some View {
        ZStack {
        VStack {
            Image(uiImage: UIImage(named: "barra.png")!)
                .resizable()
                .scaledToFit()
                .rotationEffect(.degrees(180))
            Text("Caesar cipher (or Caesar code) is a shift cipher, one of the most famous encryption systems. It uses the substitution of a letter by another one further in the alphabet.")
                .font(Font.custom("American Typewriter", size: 20.0))
                .multilineTextAlignment(.center)
                .padding(20)
            Button("Return") {
                PlaygroundPage.current.setLiveView(Riddle1())
            }
            .background(Color.blue.opacity(0.4))
            .foregroundColor(.white)
            .cornerRadius(10)
            .buttonStyle(.bordered)
            Image(uiImage: UIImage(named: "barra.png")!)
                                    .resizable()
                                    .scaledToFit()
        }
        .frame(width: 400, height: 600)
        }
    }
    }

var player: AVAudioPlayer?

func playSound() {
    guard let url = Bundle.main.url(forResource: "riddle1m", withExtension: "mp3") else { return }

    do {
        try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
        try AVAudioSession.sharedInstance().setActive(true)


        player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
        
        guard let player = player else { return }

        player.play()

    } catch let error {
        print(error.localizedDescription)
    }
}
playSound()

//:[Go to that Place](Bank)
