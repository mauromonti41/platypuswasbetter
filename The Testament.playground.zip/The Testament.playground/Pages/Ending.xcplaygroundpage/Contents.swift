import SwiftUI
import PlaygroundSupport
import Foundation
import AVFoundation
import CoreMedia
import UIKit

PlaygroundPage.current.setLiveView(Ending1())

struct Ending1: View{
    var body: some View {
        ZStack{
            Image(uiImage: UIImage(named: "FinalLetter.jpg")!)
                .resizable()
        Button(action:{},
               label: {
            Text("The End")
                .bold()
                .font(Font.custom("American Typewriter", size: 20.0))
                .foregroundColor(.brown)
                .frame(width: 400, height: 600)
                .shadow(radius: 10)
                .offset(x: -135, y: 263)
                })
        }
        .frame(width: 400, height: 600)
    }
}

var player: AVAudioPlayer?

func playSound() {
    guard let url = Bundle.main.url(forResource: "intro", withExtension: "mp3") else { return }

    do {
        try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
        try AVAudioSession.sharedInstance().setActive(true)


        player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
        
        guard let player = player else { return }

        player.play()

    } catch let error {
        print(error.localizedDescription)
    }
}
playSound()
