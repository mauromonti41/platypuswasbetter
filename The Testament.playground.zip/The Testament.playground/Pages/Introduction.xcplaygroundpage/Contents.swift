import SwiftUI
import PlaygroundSupport
import Foundation
import AVFoundation
import CoreMedia
import UIKit

PlaygroundPage.current.setLiveView(MainMenu())

struct MainMenu: View {
    
    @State private var scale: CGFloat = 1
    @State var shouldHide = false

    @State var currentView = "Part1"

    var body: some View {
        
        ZStack {
            
            Image(uiImage: UIImage(named: "MainPage3.jpg")!)
                .resizable()
            
//                .frame(width:389, height: 592)
            
            VStack {
                
//
                Button("START THE STORY"){
                    PlaygroundPage.current.setLiveView(ContentView1())
                }
                .frame(width:200, height: 30)
                .foregroundColor(.brown)
                .shadow(radius: 10)
                .font(Font.custom("American Typewriter", size: 20.0))
                .cornerRadius(10)
            }
            
        }.frame(width: 400, height: 600)
        
    }
}

struct ContentView1: View {
    
    @State var scaledUp = true
    
    var body: some View {
                VStack {
                    Image(uiImage: UIImage(named: "Graphic1Letter.jpg")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 400, height: 300)
                        .border(Color.black, width: 10)
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                        .rotationEffect(.degrees(180))
                    
                    Text("“Kind Sir, you are summoned on the 15th of October 2021 \n in my office on the Fifth Avenue, New York, number 50 at 9 am. \n Kind regards, Connor Kenway”.")
                        .frame(width: 380, height: 150)
                        .font(Font.custom("American Typewriter", size: 20.0))
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
//                        .scaleEffect(scaledUp ? 0 : 1)
//                        .animation(.linear(duration: 0.9), value: scaledUp)
//                        .onTapGesture {scaledUp.toggle()}
                            
                    Button(action:{PlaygroundPage.current.setLiveView(ContentView2())},
                           label: {
                        Text("Continue")
                            .bold()
                            .font(Font.custom("American Typewriter", size: 20.0))
                            .foregroundColor(.brown)
                            .frame(width: 400, height: 100)
                            .position(x: 200, y: 10)
                            .shadow(radius: 10)
                            })
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                    }
                .frame(width: 400, height: 600)
            }
}

struct ContentView2: View {
    
    @State var scaledUp = true
    
    var body: some View {
                VStack {
                    Image(uiImage: UIImage(named: "Graphic2.jpg")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 400, height: 300)
                        .border(Color.black, width: 10)
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                        .rotationEffect(.degrees(180))
                        .frame(width: 400, height: 50)
                    
                    Text("This is the starting point of our story, this is the way in which our characters will meet each other for the first time.")
                        .frame(width: 380, height: 150)
                        .font(Font.custom("American Typewriter", size: 20.0))
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
//                        .scaleEffect(scaledUp ? 0 : 1)
//                        .animation(.linear(duration: 0.9), value: scaledUp)
//                        .onTapGesture {scaledUp.toggle()}
                            
                    Button(action:{PlaygroundPage.current.setLiveView(ContentView33())},
                           label: {
                        Text("Continue")
                            .bold()
                            .font(Font.custom("American Typewriter", size: 20.0))
                            .foregroundColor(.brown)
                            .frame(width: 400, height: 100)
                            .position(x: 200, y: 10)
                            .shadow(radius: 10)
                            })
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                    
                    }
                .frame(width: 400, height: 600)
            }
}

/*struct ContentView3: View {
    
    @State var scaledUp = true
    
    var body: some View {
                VStack {
                    Image(uiImage: UIImage(named: "Graphic2.jpg")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 400, height: 300)
                        .border(Color.black, width: 10)
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                        .rotationEffect(.degrees(180))
                        .frame(width: 400, height: 50)
                    
                    Text("The day specified on the advise has finally come: Ethan and Liam are in front of lawyer Connor Kenway’s office, waiting for their own turn.")
                        .frame(width: 380, height: 150)
                        .font(Font.custom("American Typewriter", size: 20.0))
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
//                        .scaleEffect(scaledUp ? 0 : 1)
//                        .animation(.linear(duration: 0.9), value: scaledUp)
//                        .onTapGesture {scaledUp.toggle()}
                            
                    Button(action:{PlaygroundPage.current.setLiveView(ContentView33())},
                           label: {
                        Text("Continue")
                            .bold()
                            .font(Font.custom("American Typewriter", size: 20.0))
                            .foregroundColor(.brown)
                            .frame(width: 400, height: 100)
                            .position(x: 200, y: 10)
                            .shadow(radius: 10)
                            })
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                    
                    }
                .frame(width: 400, height: 600)
            }
}*/

struct ContentView33: View {
    
    @State var scaledUp = true
    
    var body: some View {
                VStack {
                    Image(uiImage: UIImage(named: "Graphic3.jpg")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 400, height: 300)
                        .border(Color.black, width: 10)
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                        .rotationEffect(.degrees(180))
                        .frame(width: 400, height: 50)
                    
                    Text("“Nice to meet you, my name is Liam O’Neill and you?” - “The pleasure is mine, I’m Ethan Walsh”.")
                        .frame(width: 380, height: 150)
                        .font(Font.custom("American Typewriter", size: 20.0))
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
//                        .scaleEffect(scaledUp ? 0 : 1)
//                        .animation(.linear(duration: 0.9), value: scaledUp)
//                        .onTapGesture {scaledUp.toggle()}
                            
                    Button(action:{PlaygroundPage.current.setLiveView(ContentView34())},
                           label: {
                        Text("Continue")
                            .bold()
                            .font(Font.custom("American Typewriter", size: 20.0))
                            .foregroundColor(.brown)
                            .frame(width: 400, height: 100)
                            .position(x: 200, y: 10)
                            .shadow(radius: 10)
                            })
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                    
                    }
                .frame(width: 400, height: 600)
            }
}

struct ContentView34: View {
    
    @State var scaledUp = true
    
    var body: some View {
                VStack {
                    Image(uiImage: UIImage(named: "Graphic4.jpg")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 400, height: 300)
                        .border(Color.black, width: 10)
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                        .rotationEffect(.degrees(180))
                        .frame(width: 400, height: 50)
                    
                    Text("Suddenly the lawyer invites them both to take a sit in front of his desk.")
                        .frame(width: 380, height: 150)
                        .font(Font.custom("American Typewriter", size: 20.0))
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
//                        .scaleEffect(scaledUp ? 0 : 1)
//                        .animation(.linear(duration: 0.9), value: scaledUp)
//                        .onTapGesture {scaledUp.toggle()}
                            
                    Button(action:{PlaygroundPage.current.setLiveView(ContentView35())},
                           label: {
                        Text("Continue")
                            .bold()
                            .font(Font.custom("American Typewriter", size: 20.0))
                            .foregroundColor(.brown)
                            .frame(width: 400, height: 100)
                            .position(x: 200, y: 10)
                            .shadow(radius: 10)
                            })
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                    
                    }
                .frame(width: 400, height: 600)
            }
}

struct ContentView35: View {
    
    @State var scaledUp = true
    
    var body: some View {
                VStack {
                    Image(uiImage: UIImage(named: "Graphic4.jpg")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 400, height: 300)
                        .border(Color.black, width: 10)
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                        .rotationEffect(.degrees(180))
                        .frame(width: 400, height: 50)
                    
                    Text("“Dear Gentlemen, I have the duty to tell you what follows…”")
                        .frame(width: 380, height: 150)
                        .font(Font.custom("American Typewriter", size: 20.0))
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
//                        .scaleEffect(scaledUp ? 0 : 1)
//                        .animation(.linear(duration: 0.9), value: scaledUp)
//                        .onTapGesture {scaledUp.toggle()}
                            
                    Button(action:{PlaygroundPage.current.setLiveView(ContentView36())},
                           label: {
                        Text("Continue")
                            .bold()
                            .font(Font.custom("American Typewriter", size: 20.0))
                            .foregroundColor(.brown)
                            .frame(width: 400, height: 100)
                            .position(x: 200, y: 10)
                            .shadow(radius: 10)
                            })
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                    
                    }
                .frame(width: 400, height: 600)
            }
}

struct ContentView36: View {
    
    @State var scaledUp = true
    
    var body: some View {
                VStack {
                    Image(uiImage: UIImage(named: "Graphic4.jpg")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 400, height: 300)
                        .border(Color.black, width: 10)
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                        .rotationEffect(.degrees(180))
                        .frame(width: 400, height: 50)
                    
                    Text("The lawyer immediately extracts two letters, the first one closed with sealing wax and the other already opened.")
                        .frame(width: 380, height: 150)
                        .font(Font.custom("American Typewriter", size: 20.0))
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
//                        .scaleEffect(scaledUp ? 0 : 1)
//                        .animation(.linear(duration: 0.9), value: scaledUp)
//                        .onTapGesture {scaledUp.toggle()}
                            
                    Button(action:{PlaygroundPage.current.setLiveView(ContentView37())},
                           label: {
                        Text("Continue")
                            .bold()
                            .font(Font.custom("American Typewriter", size: 20.0))
                            .foregroundColor(.brown)
                            .frame(width: 400, height: 100)
                            .position(x: 200, y: 10)
                            .shadow(radius: 10)
                            })
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                    
                    }
                .frame(width: 400, height: 600)
            }
}

struct ContentView37: View {
    
    @State var scaledUp = true
    
    var body: some View {
                VStack {
                    Image(uiImage: UIImage(named: "Graphic5.jpg")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 400, height: 300)
                        .border(Color.black, width: 10)
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                        .rotationEffect(.degrees(180))
                        .frame(width: 400, height: 50)
                    
                    Text("“These are the last wills of Reece William Byrne…”.")
                        .frame(width: 380, height: 150)
                        .font(Font.custom("American Typewriter", size: 20.0))
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
//                        .scaleEffect(scaledUp ? 0 : 1)
//                        .animation(.linear(duration: 0.9), value: scaledUp)
//                        .onTapGesture {scaledUp.toggle()}
                            
                    Button(action:{PlaygroundPage.current.setLiveView(ContentView38())},
                           label: {
                        Text("Continue")
                            .bold()
                            .font(Font.custom("American Typewriter", size: 20.0))
                            .foregroundColor(.brown)
                            .frame(width: 400, height: 100)
                            .position(x: 200, y: 10)
                            .shadow(radius: 10)
                            })
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                    
                    }
                .frame(width: 400, height: 600)
            }
}

struct ContentView38: View {
    
    @State var scaledUp = true
    
    var body: some View {
                VStack {
                    Image(uiImage: UIImage(named: "Graphic5.jpg")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 400, height: 300)
                        .border(Color.black, width: 10)
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                        .rotationEffect(.degrees(180))
                        .frame(width: 400, height: 50)
                    
                    Text("A few words, a letter and a promise of a big fortune: this is all the testament said.")
                        .frame(width: 380, height: 150)
                        .font(Font.custom("American Typewriter", size: 20.0))
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
//                        .scaleEffect(scaledUp ? 0 : 1)
//                        .animation(.linear(duration: 0.9), value: scaledUp)
//                        .onTapGesture {scaledUp.toggle()}
                            
                    Button(action:{PlaygroundPage.current.setLiveView(ContentView39())},
                           label: {
                        Text("Continue")
                            .bold()
                            .font(Font.custom("American Typewriter", size: 20.0))
                            .foregroundColor(.brown)
                            .frame(width: 400, height: 100)
                            .position(x: 200, y: 10)
                            .shadow(radius: 10)
                            })
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                    
                    }
                .frame(width: 400, height: 600)
            }
}

struct ContentView39: View {
    
   @State var scaledUp = true
    
    var body: some View {
                VStack {
                    Image(uiImage: UIImage(named: "Grafica6.jpg")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 400, height: 300)
                        .border(Color.black, width: 10)
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                        .rotationEffect(.degrees(180))
                        .frame(width: 400, height: 50)
                    
                    Text("Ethan and Liam leave and go away together. Once opened the letter they find a key and a note that says...")
                        .frame(width: 400, height: 150)
                        .font(Font.custom("American Typewriter", size: 20.0))
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
//                        .scaleEffect(scaledUp ? 0 : 1)
//                        .animation(.linear(duration: 0.9), value: scaledUp)
//                        .onTapGesture {scaledUp.toggle()}
                            
                    Button(action:{},
                           label: {
                        Text("Click on 'Solve the Riddle'")
                            .bold()
                            .font(Font.custom("American Typewriter", size: 20.0))
                            .foregroundColor(.brown)
                            .frame(width: 400, height: 100)
                            .position(x: 200, y: 10)
                            .shadow(radius: 10)
                            })
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                        .frame(width: 400, height: 50)
                    }
                .frame(width: 400, height: 600)
            }
}

var player: AVAudioPlayer?

func playSound() {
    guard let url = Bundle.main.url(forResource: "intro", withExtension: "mp3") else { return }

    do {
        try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
        try AVAudioSession.sharedInstance().setActive(true)


        player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
        
        guard let player = player else { return }

        player.play()

    } catch let error {
        print(error.localizedDescription)
    }
}
playSound()

//:[Solve the Riddle](Riddle1)
