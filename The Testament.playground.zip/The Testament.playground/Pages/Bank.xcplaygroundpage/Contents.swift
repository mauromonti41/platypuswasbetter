//:[Solve the Riddle](Riddle2)

import SwiftUI
import PlaygroundSupport
import Foundation
import AVFoundation
import CoreMedia
import UIKit

PlaygroundPage.current.setLiveView(ContentView2())

struct ContentView2: View {
    
    @State var scaledUp = true
    
    var body: some View {
        VStack {
            Image(uiImage: UIImage(named: "Grafica7.jpg")!)
                .resizable()
                .scaledToFit()
                .frame(width: 400, height: 300)
                .border(Color.black, width: 10)
            Image(uiImage: UIImage(named: "barra.png")!)
                .resizable()
                .rotationEffect(.degrees(180))
                .frame(width: 400, height: 50)
            
            Text("They immediately go to the indicated bank and ask to enter the vault.")
                .frame(width: 400, height: 150)
                .font(Font.custom("American Typewriter", size: 20.0))
                .foregroundColor(.black)
                .multilineTextAlignment(.center)
                /*.scaleEffect(scaledUp ? 0 : 1)
                .animation(.linear(duration: 0.9), value: scaledUp)
                .onTapGesture {scaledUp.toggle()}*/
                    
            Button(action:{PlaygroundPage.current.setLiveView(ContentView3())},
                   label: {
                Text("Continue")
                    .bold()
                    .font(Font.custom("American Typewriter", size: 20.0))
                    .foregroundColor(.brown)
                    .frame(width: 400, height: 100)
                    .position(x: 200, y: 10)
                    .shadow(radius: 10)
                    })
            Image(uiImage: UIImage(named: "barra.png")!)
                .resizable()
                .frame(width: 400, height: 50)
            }
        .frame(width: 400, height: 600)
                    }
                }
            
struct ContentView3: View {
    
    @State var scaledUp = true
    
    var body: some View {
        VStack {
            ZStack{
            Image(uiImage: UIImage(named: "Grafica8.jpg")!)
                .resizable()
                .scaledToFit()
                .frame(width: 400, height: 300)
                .border(Color.black, width: 10)
//                if(scaledUp==false){
            Image(uiImage: UIImage(named: "nuvolabyrne.png")!)
                    .resizable()
                    .frame(width: 75, height: 75)
                    .position(x: 200, y: 45)
                    /*.scaleEffect(scaledUp ? 0 : 1)
                    .animation(.linear(duration: 0.9), value: scaledUp)*/
//                }
            }
            Image(uiImage: UIImage(named: "barra.png")!)
                .resizable()
                .rotationEffect(.degrees(180))
                .frame(width: 400, height: 50)
            
            Text("A banker stops them and asks for the owner of the box. “Mr. Byrne…” they say.")
                .frame(width: 400, height: 150)
                .font(Font.custom("American Typewriter", size: 20.0))
                .foregroundColor(.black)
                .multilineTextAlignment(.center)
                /*.scaleEffect(scaledUp ? 0 : 1)
                .animation(.linear(duration: 0.9), value: scaledUp)
                .onTapGesture {scaledUp.toggle()}*/
                    
            Button(action:{PlaygroundPage.current.setLiveView(ContentView4())},
                   label: {
                Text("Continue")
                    .bold()
                    .font(Font.custom("American Typewriter", size: 20.0))
                    .foregroundColor(.brown)
                    .frame(width: 400, height: 100)
                    .position(x: 200, y: 10)
                    .shadow(radius: 10)
                    })
            Image(uiImage: UIImage(named: "barra.png")!)
                .resizable()
                .frame(width: 400, height: 50)
            }
        .frame(width: 400, height: 600)
                    }
                }

struct ContentView4: View {
    
    @State var scaledUp = true
    
    var body: some View {
        VStack {
            ZStack{
            Image(uiImage: UIImage(named: "Grafica8.jpg")!)
                .resizable()
                .scaledToFit()
                .frame(width: 400, height: 300)
                .border(Color.black, width: 10)
//                if(scaledUp==false){
            Image(uiImage: UIImage(named: "apologize.png")!)
                    .resizable()
                    .frame(width: 75, height: 75)
                    .position(x: 100, y: 45)
                    /*.scaleEffect(scaledUp ? 0 : 1)
                    .animation(.linear(duration: 0.1), value: scaledUp)*/
//                }
            }
            Image(uiImage: UIImage(named: "barra.png")!)
                .resizable()
                .rotationEffect(.degrees(180))
                .frame(width: 400, height: 50)
            
            Text("“I have to apologize but it doesn't result...”. Liam tries the unbelievable...")
                .frame(width: 400, height: 150)
                .font(Font.custom("American Typewriter", size: 20.0))
                .foregroundColor(.black)
                .multilineTextAlignment(.center)
                /*.scaleEffect(scaledUp ? 0 : 1)
                .animation(.linear(duration: 0.9), value: scaledUp)
                .onTapGesture {scaledUp.toggle()}*/
                    
            Button(action:{PlaygroundPage.current.setLiveView(ContentView5())},
                   label: {
                Text("Continue")
                    .bold()
                    .font(Font.custom("American Typewriter", size: 20.0))
                    .foregroundColor(.brown)
                    .frame(width: 400, height: 100)
                    .position(x: 200, y: 10)
                    .shadow(radius: 10)
                    })
            Image(uiImage: UIImage(named: "barra.png")!)
                .resizable()
                .frame(width: 400, height: 50)
            }
        .frame(width: 400, height: 600)
                    }
                }

struct ContentView5: View {
    
    @State var scaledUp = true
    
    var body: some View {
        VStack {
            ZStack{
            Image(uiImage: UIImage(named: "GraficaExtra.jpg")!)
                .resizable()
                .scaledToFit()
                .frame(width: 400, height: 300)
                .border(Color.black, width: 10)
                
//                if scaledUp==false{
            Image(uiImage: UIImage(named: "mrdialogue.png")!)
                    .resizable()
                    .frame(width: 75, height: 75)
                    .position(x: 200, y: 45)
                    /*.scaleEffect(scaledUp ? 0 : 1)
                    .animation(.linear(duration: 0.9), value: scaledUp)*/
//            }
            }
            Image(uiImage: UIImage(named: "barra.png")!)
                .resizable()
                .rotationEffect(.degrees(180))
                .frame(width: 400, height: 50)
            
            Text("“Are Mr. O’Neill and Mr. Walsh the owners you look for?” “Exactly, you can follow me in the vault” says the banker.")
                .frame(width: 400, height: 150)
                .font(Font.custom("American Typewriter", size: 20.0))
                .foregroundColor(.black)
                .multilineTextAlignment(.center)
               /* .scaleEffect(scaledUp ? 0 : 1)
                .animation(.linear(duration: 0.9), value: scaledUp)
                .onTapGesture {scaledUp.toggle()}*/
                    
            Button(action:{PlaygroundPage.current.setLiveView(View9())},
                   label: {
                Text("Continue")
                    .bold()
                    .font(Font.custom("American Typewriter", size: 20.0))
                    .foregroundColor(.brown)
                    .frame(width: 400, height: 100)
                    .position(x: 200, y: 10)
                    .shadow(radius: 10)
                    })
            Image(uiImage: UIImage(named: "barra.png")!)
                .resizable()
                .frame(width: 400, height: 50)
            }
        .frame(width: 400, height: 600)
                    }
                }

struct View9: View {
    
    @State var scaledUp = true
    
    var body: some View {
                VStack {
                    Image(uiImage: UIImage(named: "grafica9.jpg")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 400, height: 300)
                        .border(Color.black, width: 10)
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                        .rotationEffect(.degrees(180))
                    
                    Text("Ethan and Liam get inside the vault and finally open the security box where there is another message:")
                        .frame(width: 400, height: 150)
                        .font(Font.custom("American Typewriter", size: 20.0))
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                        /*.scaleEffect(scaledUp ? 0 : 1)
                        .animation(.linear(duration: 0.9), value: scaledUp)
                        .onTapGesture {scaledUp.toggle()}*/
                            
                    Button(action:{PlaygroundPage.current.setLiveView(View101())},
                           label: {
                        Text("Continue")
                            .bold()
                            .font(Font.custom("American Typewriter", size: 20.0))
                            .foregroundColor(.brown)
                            .frame(width: 400, height: 100)
                            .position(x: 200, y: 10)
                            .shadow(radius: 10)
                            })
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                    }
                .frame(width: 400, height: 600)
            }
}

struct View101: View {
    
    @State var scaledUp = true
    
    var body: some View {
                VStack {
                    Image(uiImage: UIImage(named: "grafica10.jpg")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 400, height: 300)
                        .border(Color.black, width: 10)
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                        .rotationEffect(.degrees(180))
                    
                    Text("'This box doesn’t contain what you could be thinking I’ve promised, but trust me and follow this map.'")
                        .frame(width: 400, height: 150)
                        .font(Font.custom("American Typewriter", size: 20.0))
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                        /*.scaleEffect(scaledUp ? 0 : 1)
                        .animation(.linear(duration: 0.9), value: scaledUp)
                        .onTapGesture {scaledUp.toggle()}*/
                            
                    Button(action:{},
                           label: {
                        Text("Click on 'Solve the Riddle'")
                            .bold()
                            .font(Font.custom("American Typewriter", size: 20.0))
                            .foregroundColor(.brown)
                            .frame(width: 400, height: 100)
                            .position(x: 200, y: 10)
                            .shadow(radius: 10)
                            })
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                    }
                .frame(width: 400, height: 600)
            }
}
/*
struct View102: View {
    
    @State var scaledUp = true
    
    var body: some View {
                VStack {
                    Image(uiImage: UIImage(named: "grafica10.jpg")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 400, height: 300)
                        .border(Color.black, width: 10)
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                        .rotationEffect(.degrees(180))
                    
                    Text("...more than all the gold you can imagine, just follow this map and get where I want you to go. The truth is close but you will have to find it together.'")
                        .frame(width: 400, height: 150)
                        .font(Font.custom("American Typewriter", size: 20.0))
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                        .scaleEffect(scaledUp ? 0 : 1)
                        .animation(.linear(duration: 0.9), value: scaledUp)
                        .onTapGesture {scaledUp.toggle()}
                            
                    Button(action:{PlaygroundPage.current.setLiveView(View103())},
                           label: {
                        Text("Continue")
                            .bold()
                            .font(Font.custom("American Typewriter", size: 20.0))
                            .foregroundColor(.brown)
                            .frame(width: 400, height: 100)
                            .position(x: 200, y: 10)
                            .shadow(radius: 10)
                            })
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                    }
                .frame(width: 400, height: 600)
            }
}

struct View103: View {
    
    @State var scaledUp = true
    
    var body: some View {
                VStack {
                    Image(uiImage: UIImage(named: "grafica10.jpg")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 400, height: 300)
                        .border(Color.black, width: 10)
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                        .rotationEffect(.degrees(180))
                    
                    Text("The two guys are terrified and astonished at the same time, they wonder what they will find. At this point they can’t stand back and decide to reach the mysterious place.")
                        .frame(width: 400, height: 150)
                        .font(Font.custom("American Typewriter", size: 20.0))
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                        .scaleEffect(scaledUp ? 0 : 1)
                        .animation(.linear(duration: 0.9), value: scaledUp)
                        .onTapGesture {scaledUp.toggle()}
                            
                    Button(action:{},
                           label: {
                        Text("Click on 'Solve the Riddle'")
                            .bold()
                            .font(Font.custom("American Typewriter", size: 20.0))
                            .foregroundColor(.brown)
                            .frame(width: 400, height: 100)
                            .position(x: 200, y: 10)
                            .shadow(radius: 10)
                            })
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                    }
                .frame(width: 400, height: 600)
            }
}*/

var player: AVAudioPlayer?

func playSound() {
    guard let url = Bundle.main.url(forResource: "after1riddle", withExtension: "mp3") else { return }

    do {
        try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
        try AVAudioSession.sharedInstance().setActive(true)


        player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
        
        guard let player = player else { return }

        player.play()

    } catch let error {
        print(error.localizedDescription)
    }
}
playSound()

//:[Solve the Riddle](Riddle2)
